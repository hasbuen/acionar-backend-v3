"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const jwt_1 = require("@nestjs/jwt");
let NotificationsGateway = class NotificationsGateway {
    constructor(jwtService) {
        this.jwtService = jwtService;
    }
    async handleConnection(client) {
        try {
            const token = client.handshake.auth?.token || client.handshake.headers?.authorization?.split(' ')[1];
            if (!token) {
                console.log(`[SOCKET] Connection rejected: No token provided (${client.id})`);
                client.disconnect();
                return;
            }
            const decoded = this.jwtService.verify(token);
            client.data.user = decoded;
            if (decoded.tenant_slug) {
                const tenantRoom = `tenant_${decoded.tenant_slug.toLowerCase().trim()}`;
                client.join(tenantRoom);
                console.log(`[SOCKET] Authenticated client ${client.id} joined room ${tenantRoom}`);
                if (decoded.profissional_id) {
                    const userRoom = `user_${decoded.profissional_id}`;
                    client.join(userRoom);
                    console.log(`[SOCKET] Authenticated client ${client.id} joined user room ${userRoom}`);
                }
            }
        }
        catch (err) {
            console.log(`[SOCKET] Connection rejected: Invalid token (${client.id}) - ${err.message}`);
            client.disconnect();
        }
    }
    handleDisconnect(client) {
        console.log(`[SOCKET] Client disconnected: ${client.id}`);
    }
    handleJoinTenant(client, data) {
        const user = client.data.user;
        const resolvedSlug = user?.tenant_slug || data?.tenantSlug;
        if (resolvedSlug) {
            const tenantRoom = `tenant_${resolvedSlug.toLowerCase().trim()}`;
            client.join(tenantRoom);
            console.log(`[SOCKET] Client ${client.id} explicitly joined room ${tenantRoom}`);
            const resolvedProfId = user?.profissional_id || data?.profissionalId;
            if (resolvedProfId) {
                const userRoom = `user_${resolvedProfId}`;
                client.join(userRoom);
                console.log(`[SOCKET] Client ${client.id} explicitly joined user room ${userRoom}`);
            }
        }
    }
    broadcastToTenant(tenantSlug, event, payload) {
        const tenantRoom = `tenant_${tenantSlug.toLowerCase().trim()}`;
        if (this.server) {
            this.server.to(tenantRoom).emit(event, payload);
            console.log(`[SOCKET] Emitted ${event} to room ${tenantRoom}`);
        }
        else {
            console.warn('[SOCKET] Server is not initialized yet.');
        }
    }
    emitToUser(profissionalId, event, payload) {
        const userRoom = `user_${profissionalId}`;
        if (this.server) {
            this.server.to(userRoom).emit(event, payload);
            console.log(`[SOCKET] Emitted ${event} to user room ${userRoom}`);
        }
    }
};
exports.NotificationsGateway = NotificationsGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], NotificationsGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('join-tenant'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], NotificationsGateway.prototype, "handleJoinTenant", null);
exports.NotificationsGateway = NotificationsGateway = __decorate([
    (0, websockets_1.WebSocketGateway)({
        path: '/api/socket.io',
        cors: {
            origin: '*',
        },
    }),
    __metadata("design:paramtypes", [jwt_1.JwtService])
], NotificationsGateway);
//# sourceMappingURL=notifications.gateway.js.map