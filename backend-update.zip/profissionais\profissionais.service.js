"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfissionaisService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const bcrypt = require("bcryptjs");
let ProfissionaisService = class ProfissionaisService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findAll(tenantSlug) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const profissionais = await this.prisma.$queryRawUnsafe(`SELECT id, nome, email, telefone, cargo, foto_url, ativo,
                cor_identificadora, aceita_atendimento_externo, created_at
         FROM profissionais
         ORDER BY (cargo = 'proprietario') DESC, nome ASC`);
            return { profissionais };
        });
    }
    async create(tenantSlug, dto) {
        const { nome, email, senha, cor_identificadora, aceita_atendimento_externo, cargo } = dto;
        if (!nome || !email || !senha) {
            throw new common_1.BadRequestException('Nome, e-mail e senha são obrigatórios.');
        }
        const cleanEmail = email.toLowerCase().trim();
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const existing = await this.prisma.$queryRawUnsafe('SELECT id FROM profissionais WHERE email = $1', cleanEmail);
            if (existing && existing.length > 0) {
                throw new common_1.ConflictException(`E-mail '${cleanEmail}' já está cadastrado.`);
            }
            const salt = await bcrypt.genSalt(10);
            const senha_hash = await bcrypt.hash(senha, salt);
            const res = await this.prisma.$queryRawUnsafe(`INSERT INTO profissionais (
          nome, email, senha_hash, cargo, cor_identificadora, aceita_atendimento_externo, ativo
        ) VALUES ($1, $2, $3, $4, $5, $6, true) RETURNING id, nome, email, cargo, cor_identificadora, aceita_atendimento_externo, ativo`, nome, cleanEmail, senha_hash, cargo || 'auxiliar', cor_identificadora || '#8c52ff', Boolean(aceita_atendimento_externo));
            return { profissional: res[0] };
        });
    }
    async update(tenantSlug, id, dto) {
        const { nome, email, senha, cor_identificadora, aceita_atendimento_externo, ativo } = dto;
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const existing = await this.prisma.$queryRawUnsafe('SELECT * FROM profissionais WHERE id = $1', id);
            if (!existing || existing.length === 0) {
                throw new common_1.NotFoundException('Profissional não encontrado.');
            }
            let senha_hash = existing[0].senha_hash;
            if (senha && senha.trim() !== '') {
                const salt = await bcrypt.genSalt(10);
                senha_hash = await bcrypt.hash(senha, salt);
            }
            const cleanEmail = email ? email.toLowerCase().trim() : existing[0].email;
            const res = await this.prisma.$queryRawUnsafe(`UPDATE profissionais
         SET nome = COALESCE($1, nome),
             email = COALESCE($2, email),
             senha_hash = $3,
             cor_identificadora = COALESCE($4, cor_identificadora),
             aceita_atendimento_externo = COALESCE($5, aceita_atendimento_externo),
             ativo = COALESCE($6, ativo)
         WHERE id = $7
         RETURNING id, nome, email, cargo, cor_identificadora, aceita_atendimento_externo, ativo`, nome || null, cleanEmail || null, senha_hash, cor_identificadora || null, aceita_atendimento_externo !== undefined ? Boolean(aceita_atendimento_externo) : null, ativo !== undefined ? Boolean(ativo) : null, id);
            return { profissional: res[0] };
        });
    }
    async remove(tenantSlug, id) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const existing = await this.prisma.$queryRawUnsafe('SELECT cargo FROM profissionais WHERE id = $1', id);
            if (!existing || existing.length === 0) {
                throw new common_1.NotFoundException('Profissional não encontrado.');
            }
            if (existing[0].cargo === 'proprietario') {
                throw new common_1.BadRequestException('Não é possível remover o profissional proprietário.');
            }
            await this.prisma.$queryRawUnsafe('DELETE FROM profissionais WHERE id = $1', id);
            return { message: 'Auxiliar removido com sucesso.' };
        });
    }
};
exports.ProfissionaisService = ProfissionaisService;
exports.ProfissionaisService = ProfissionaisService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ProfissionaisService);
//# sourceMappingURL=profissionais.service.js.map