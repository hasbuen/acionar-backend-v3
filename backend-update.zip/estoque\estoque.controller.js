"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EstoqueController = void 0;
const common_1 = require("@nestjs/common");
const estoque_service_1 = require("./estoque.service");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
let EstoqueController = class EstoqueController {
    constructor(estoqueService) {
        this.estoqueService = estoqueService;
    }
    async findProdutos(req) {
        return this.estoqueService.findProdutos(req.user.tenant_slug, req.user);
    }
    async createProduto(req, body) {
        return this.estoqueService.createProduto(req.user.tenant_slug, req.user, body);
    }
    async findMovimentacoes(req, query) {
        return this.estoqueService.findMovimentacoes(req.user.tenant_slug, req.user, query);
    }
    async createMovimentacao(req, body) {
        return this.estoqueService.createMovimentacao(req.user.tenant_slug, req.user, body);
    }
    async transferProduto(req, body) {
        return this.estoqueService.transferProduto(req.user.tenant_slug, req.user, body);
    }
    async findAlerts(req) {
        return this.estoqueService.findAlerts(req.user.tenant_slug, req.user);
    }
    async deleteProduto(req, id) {
        return this.estoqueService.deleteProduto(req.user.tenant_slug, req.user, Number(id));
    }
};
exports.EstoqueController = EstoqueController;
__decorate([
    (0, common_1.Get)('produtos'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "findProdutos", null);
__decorate([
    (0, common_1.Post)('produtos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "createProduto", null);
__decorate([
    (0, common_1.Get)('movimentacoes'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "findMovimentacoes", null);
__decorate([
    (0, common_1.Post)('movimentacoes'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "createMovimentacao", null);
__decorate([
    (0, common_1.Post)('transferencias'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "transferProduto", null);
__decorate([
    (0, common_1.Get)('alertas'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "findAlerts", null);
__decorate([
    (0, common_1.Delete)('produtos/:id'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], EstoqueController.prototype, "deleteProduto", null);
exports.EstoqueController = EstoqueController = __decorate([
    (0, common_1.Controller)('api/estoque'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [estoque_service_1.EstoqueService])
], EstoqueController);
//# sourceMappingURL=estoque.controller.js.map