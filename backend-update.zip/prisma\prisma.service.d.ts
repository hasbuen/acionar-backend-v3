import { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient, Prisma } from '@prisma/client';
export declare class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
    private tenantClients;
    onModuleInit(): Promise<void>;
    onModuleDestroy(): Promise<void>;
    getTenantSchemaName(slug: string): string;
    getTenantDbUrl(slug: string): string;
    getTenantClient(slug: string): PrismaClient;
    $queryRawUnsafe<T = any>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;
    $executeRawUnsafe(query: string, ...values: any[]): Prisma.PrismaPromise<number>;
    runInTenantSchema<T>(slug: string, callback: () => Promise<T>): Promise<T>;
    ensureTenantSchema(slug: string): Promise<void>;
}
