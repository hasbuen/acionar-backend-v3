import { PrismaService } from '../prisma/prisma.service';
import { NotificationsGateway } from './notifications.gateway';
export declare class CronService {
    private readonly prisma;
    private readonly gateway;
    private readonly logger;
    constructor(prisma: PrismaService, gateway: NotificationsGateway);
    handleCron(): Promise<void>;
    private notify;
    private checkCaixaAtrasado;
    private checkEstoqueBaixo;
    private checkAgendamentoProximo;
    private checkManutencao;
}
