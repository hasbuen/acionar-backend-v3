import { PrismaService } from '../prisma/prisma.service';
export declare class ConfigService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getPaymentConfig(tenantSlug: string): Promise<{
        settings: any;
    }>;
    updatePaymentConfig(tenantSlug: string, dto: any): Promise<{
        message: string;
        settings: {
            asaas_enabled: boolean;
            asaas_environment: string;
            pix_key: string;
            pix_key_type: string;
        };
    }>;
    getPublicScheduleConfig(tenantSlug: string): Promise<{
        settings: {
            slug: string;
            subdominio: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    updatePublicScheduleConfig(tenantSlug: string, dto: any): Promise<{
        message: string;
        settings: {
            slug: string;
            subdominio: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    getMessageConfig(tenantSlug: string): Promise<{
        settings: any;
    }>;
    updateMessageConfig(tenantSlug: string, dto: any): Promise<{
        message: string;
        settings: {
            endereco: any;
            template_confirmacao: any;
            template_manutencao: any;
        };
    }>;
    getBotFlow(tenantSlug: string): Promise<{
        flow: any;
    }>;
    updateBotFlow(tenantSlug: string, flowData: any): Promise<{
        message: string;
        flow: any;
    }>;
    private getUploadsDir;
    uploadLogo(tenantSlug: string, imageBase64: string): Promise<{
        message: string;
        foto_url: string;
        tenant: {
            id: number;
            slug: string;
            subdominio: string | null;
            nome_empresa: string;
            email_proprietario: string;
            telefone: string | null;
            senha_hash: string;
            status: string;
            foto_url: string | null;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
            created_at: Date;
            updated_at: Date;
        };
    }>;
    uploadImage(tenantSlug: string, type: 'servicos' | 'subservicos' | 'produtos', imageBase64: string): Promise<{
        message: string;
        foto_url: string;
    }>;
}
