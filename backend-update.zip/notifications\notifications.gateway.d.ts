import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
export declare class NotificationsGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private readonly jwtService;
    server: Server;
    constructor(jwtService: JwtService);
    handleConnection(client: Socket): Promise<void>;
    handleDisconnect(client: Socket): void;
    handleJoinTenant(client: Socket, data: {
        tenantSlug: string;
        profissionalId: number;
    }): void;
    broadcastToTenant(tenantSlug: string, event: string, payload: any): void;
    emitToUser(profissionalId: number, event: string, payload: any): void;
}
