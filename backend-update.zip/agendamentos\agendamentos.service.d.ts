import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationsGateway } from '../notifications/notifications.gateway';
import { WhatsappService } from '../whatsapp/whatsapp.service';
export declare class AgendamentosService {
    private readonly prisma;
    private readonly notificationsService;
    private readonly notificationsGateway;
    private readonly whatsappService;
    constructor(prisma: PrismaService, notificationsService: NotificationsService, notificationsGateway: NotificationsGateway, whatsappService: WhatsappService);
    findAll(tenantSlug: string, user: any, query: any): Promise<{
        agendamentos: any;
    }>;
    create(tenantSlug: string, user: any, dto: any): Promise<{
        agendamento: any;
    }>;
    update(tenantSlug: string, id: number, dto: any, user?: any): Promise<{
        message: string;
        agendamento: any;
    } | {
        agendamento: any;
        message?: undefined;
    }>;
    private consumirProdutosAgendamento;
    remove(tenantSlug: string, user: any, id: number): Promise<{
        message: string;
    }>;
    getPaymentData(tenantSlug: string, id: number): Promise<{
        pixKey: string;
        paymentLink: string;
        valorFinal: string;
    }>;
}
