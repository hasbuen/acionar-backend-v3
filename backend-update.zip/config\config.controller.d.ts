import { ConfigService } from './config.service';
export declare class ConfigController {
    private readonly configService;
    constructor(configService: ConfigService);
    getPublicScheduleConfig(req: any): Promise<{
        settings: {
            slug: string;
            subdominio: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    getPaymentConfig(req: any): Promise<{
        settings: any;
    }>;
    updatePaymentConfig(req: any, body: any): Promise<{
        message: string;
        settings: {
            asaas_enabled: boolean;
            asaas_environment: string;
            pix_key: string;
            pix_key_type: string;
        };
    }>;
    updatePublicScheduleConfig(req: any, body: any): Promise<{
        message: string;
        settings: {
            slug: string;
            subdominio: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    getMessageConfig(req: any): Promise<{
        settings: any;
    }>;
    updateMessageConfig(req: any, body: any): Promise<{
        message: string;
        settings: {
            endereco: any;
            template_confirmacao: any;
            template_manutencao: any;
        };
    }>;
    getBotFlow(req: any): Promise<{
        flow: any;
    }>;
    updateBotFlow(req: any, body: any): Promise<{
        message: string;
        flow: any;
    }>;
    uploadLogo(req: any, body: {
        imageBase64: string;
    }): Promise<{
        message: string;
        foto_url: string;
        tenant: {
            id: number;
            slug: string;
            subdominio: string | null;
            nome_empresa: string;
            email_proprietario: string;
            telefone: string | null;
            senha_hash: string;
            status: string;
            foto_url: string | null;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
            created_at: Date;
            updated_at: Date;
        };
    }>;
    uploadImage(req: any, body: {
        type: 'servicos' | 'subservicos' | 'produtos';
        imageBase64: string;
    }): Promise<{
        message: string;
        foto_url: string;
    }>;
}
