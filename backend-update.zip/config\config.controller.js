"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigController = void 0;
const common_1 = require("@nestjs/common");
const config_service_1 = require("./config.service");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
let ConfigController = class ConfigController {
    constructor(configService) {
        this.configService = configService;
    }
    async getPublicScheduleConfig(req) {
        return this.configService.getPublicScheduleConfig(req.user.tenant_slug);
    }
    async getPaymentConfig(req) {
        return this.configService.getPaymentConfig(req.user.tenant_slug);
    }
    async updatePaymentConfig(req, body) {
        if (req.user.cargo === 'auxiliar') {
            throw new common_1.ForbiddenException('Acesso negado.');
        }
        return this.configService.updatePaymentConfig(req.user.tenant_slug, body);
    }
    async updatePublicScheduleConfig(req, body) {
        if (req.user.cargo === 'auxiliar') {
            throw new common_1.ForbiddenException('Acesso negado.');
        }
        return this.configService.updatePublicScheduleConfig(req.user.tenant_slug, body);
    }
    async getMessageConfig(req) {
        return this.configService.getMessageConfig(req.user.tenant_slug);
    }
    async updateMessageConfig(req, body) {
        if (req.user.cargo === 'auxiliar') {
            throw new common_1.ForbiddenException('Acesso negado.');
        }
        return this.configService.updateMessageConfig(req.user.tenant_slug, body);
    }
    async getBotFlow(req) {
        return this.configService.getBotFlow(req.user.tenant_slug);
    }
    async updateBotFlow(req, body) {
        if (req.user.cargo === 'auxiliar') {
            throw new common_1.ForbiddenException('Acesso negado.');
        }
        return this.configService.updateBotFlow(req.user.tenant_slug, body);
    }
    async uploadLogo(req, body) {
        if (req.user.cargo === 'auxiliar') {
            throw new common_1.ForbiddenException('Acesso negado.');
        }
        return this.configService.uploadLogo(req.user.tenant_slug, body.imageBase64);
    }
    async uploadImage(req, body) {
        return this.configService.uploadImage(req.user.tenant_slug, body.type, body.imageBase64);
    }
};
exports.ConfigController = ConfigController;
__decorate([
    (0, common_1.Get)('public-schedule'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "getPublicScheduleConfig", null);
__decorate([
    (0, common_1.Get)('payments'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "getPaymentConfig", null);
__decorate([
    (0, common_1.Put)('payments'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "updatePaymentConfig", null);
__decorate([
    (0, common_1.Put)('public-schedule'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "updatePublicScheduleConfig", null);
__decorate([
    (0, common_1.Get)('messages'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "getMessageConfig", null);
__decorate([
    (0, common_1.Put)('messages'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "updateMessageConfig", null);
__decorate([
    (0, common_1.Get)('bot-flow'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "getBotFlow", null);
__decorate([
    (0, common_1.Put)('bot-flow'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "updateBotFlow", null);
__decorate([
    (0, common_1.Post)('upload-logo'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "uploadLogo", null);
__decorate([
    (0, common_1.Post)('upload-image'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConfigController.prototype, "uploadImage", null);
exports.ConfigController = ConfigController = __decorate([
    (0, common_1.Controller)('api/config'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [config_service_1.ConfigService])
], ConfigController);
//# sourceMappingURL=config.controller.js.map