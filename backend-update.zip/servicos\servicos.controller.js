"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServicosController = void 0;
const common_1 = require("@nestjs/common");
const servicos_service_1 = require("./servicos.service");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
let ServicosController = class ServicosController {
    constructor(servicosService) {
        this.servicosService = servicosService;
    }
    async findAll(req) {
        return this.servicosService.findAll(req.user.tenant_slug, req.user);
    }
    async toggleServicoAtendo(req, id) {
        return this.servicosService.toggleServicoAtendo(req.user.tenant_slug, req.user, parseInt(id, 10));
    }
    async toggleSubservicoAtendo(req, subId) {
        return this.servicosService.toggleSubservicoAtendo(req.user.tenant_slug, req.user, parseInt(subId, 10));
    }
    async create(req, body) {
        return this.servicosService.create(req.user.tenant_slug, req.user, body);
    }
    async update(req, id, body) {
        return this.servicosService.update(req.user.tenant_slug, req.user, parseInt(id, 10), body);
    }
    async delete(req, id) {
        return this.servicosService.deleteServico(req.user.tenant_slug, req.user, parseInt(id, 10));
    }
    async createSubservico(req, id, body) {
        return this.servicosService.createSubservico(req.user.tenant_slug, req.user, parseInt(id, 10), body);
    }
    async updateSubservico(req, id, subId, body) {
        return this.servicosService.updateSubservico(req.user.tenant_slug, req.user, parseInt(subId, 10), body);
    }
    async deleteSubservico(req, id, subId) {
        return this.servicosService.deleteSubservico(req.user.tenant_slug, req.user, parseInt(subId, 10));
    }
    async vincularProduto(req, id, body) {
        return this.servicosService.vincularProduto(req.user.tenant_slug, parseInt(id, 10), body);
    }
    async removerVinculo(req, id, produtoId) {
        return this.servicosService.removerVinculoProduto(req.user.tenant_slug, parseInt(id, 10), parseInt(produtoId, 10));
    }
    async listarProdutos(req, id) {
        return this.servicosService.listarProdutosServico(req.user.tenant_slug, parseInt(id, 10));
    }
    async vincularProdutoSubservico(req, id, subId, body) {
        return this.servicosService.vincularProdutoSubservico(req.user.tenant_slug, parseInt(subId, 10), body);
    }
    async removerVinculoSubservico(req, id, subId, produtoId) {
        return this.servicosService.removerVinculoProdutoSubservico(req.user.tenant_slug, parseInt(subId, 10), parseInt(produtoId, 10));
    }
    async listarProdutosSubservico(req, id, subId) {
        return this.servicosService.listarProdutosSubservico(req.user.tenant_slug, parseInt(subId, 10));
    }
};
exports.ServicosController = ServicosController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(':id/toggle-atendo'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "toggleServicoAtendo", null);
__decorate([
    (0, common_1.Post)('subservicos/:subId/toggle-atendo'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('subId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "toggleSubservicoAtendo", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)(':id/subservicos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "createSubservico", null);
__decorate([
    (0, common_1.Put)(':id/subservicos/:subId'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('subId')),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "updateSubservico", null);
__decorate([
    (0, common_1.Delete)(':id/subservicos/:subId'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('subId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "deleteSubservico", null);
__decorate([
    (0, common_1.Post)(':id/produtos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "vincularProduto", null);
__decorate([
    (0, common_1.Delete)(':id/produtos/:produtoId'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('produtoId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "removerVinculo", null);
__decorate([
    (0, common_1.Get)(':id/produtos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "listarProdutos", null);
__decorate([
    (0, common_1.Post)(':id/subservicos/:subId/produtos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('subId')),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, Object]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "vincularProdutoSubservico", null);
__decorate([
    (0, common_1.Delete)(':id/subservicos/:subId/produtos/:produtoId'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('subId')),
    __param(3, (0, common_1.Param)('produtoId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "removerVinculoSubservico", null);
__decorate([
    (0, common_1.Get)(':id/subservicos/:subId/produtos'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('subId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], ServicosController.prototype, "listarProdutosSubservico", null);
exports.ServicosController = ServicosController = __decorate([
    (0, common_1.Controller)('api/servicos'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [servicos_service_1.ServicosService])
], ServicosController);
//# sourceMappingURL=servicos.controller.js.map