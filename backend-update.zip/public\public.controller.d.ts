import { PublicService } from './public.service';
export declare class PublicController {
    private readonly publicService;
    constructor(publicService: PublicService);
    getTenantPublicInfo(slug: string): Promise<{
        tenant: {
            slug: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    getPublicServices(slug: string): Promise<{
        servicos: any;
    }>;
    getPublicProfessionals(slug: string): Promise<{
        profissionais: any;
    }>;
    createPublicAppointment(slug: string, body: any): Promise<{
        message: string;
        agendamento: any;
    }>;
    confirmQuickAppointment(slug: string, id: string, clienteNome?: string, whatsapp?: string): Promise<{
        ok: boolean;
        message: string;
        agendamento?: undefined;
        messageConfig?: undefined;
        clienteNome?: undefined;
        whatsappPhone?: undefined;
        servicoNome?: undefined;
    } | {
        ok: boolean;
        agendamento: any;
        messageConfig: any;
        clienteNome: any;
        whatsappPhone: string;
        servicoNome: string;
        message?: undefined;
    }>;
    handleAsaasWebhook(body: any): Promise<{
        ok: boolean;
        message: string;
        error?: undefined;
    } | {
        ok: boolean;
        message?: undefined;
        error?: undefined;
    } | {
        ok: boolean;
        error: any;
        message?: undefined;
    }>;
    handleWhatsappWebhook(body: any): Promise<{
        ok: boolean;
        appointmentId: any;
        status: string;
        error?: undefined;
    } | {
        ok: boolean;
        skipped: boolean;
        reason: string;
        error?: undefined;
    } | {
        ok: boolean;
        error: string;
        skipped?: undefined;
        reason?: undefined;
    }>;
}
