export declare class ServicosModule {
}
