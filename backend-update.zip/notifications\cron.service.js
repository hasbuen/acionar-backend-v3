"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CronService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CronService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../prisma/prisma.service");
const notifications_gateway_1 = require("./notifications.gateway");
let CronService = CronService_1 = class CronService {
    constructor(prisma, gateway) {
        this.prisma = prisma;
        this.gateway = gateway;
        this.logger = new common_1.Logger(CronService_1.name);
    }
    async handleCron() {
        this.logger.log('Iniciando rotina de checagem de notificações (Cron)...');
        try {
            const tenants = await this.prisma.$queryRawUnsafe("SELECT slug FROM public.tenants WHERE status = 'ativo'");
            for (const t of tenants) {
                const tenantSlug = t.slug;
                await this.prisma.ensureTenantSchema(tenantSlug);
                await this.prisma.runInTenantSchema(tenantSlug, async () => {
                    const profissionais = await this.prisma.$queryRawUnsafe('SELECT id FROM profissionais WHERE ativo = true');
                    if (!profissionais || profissionais.length === 0)
                        return;
                    for (const prof of profissionais) {
                        const profId = prof.id;
                        await this.checkCaixaAtrasado(profId);
                        await this.checkEstoqueBaixo(profId);
                        await this.checkAgendamentoProximo(profId);
                        await this.checkManutencao(profId);
                    }
                });
            }
            this.logger.log('Rotina de notificações finalizada com sucesso.');
        }
        catch (error) {
            this.logger.error('Erro ao executar rotina de notificações:', error);
        }
    }
    async notify(profId, titulo, mensagem) {
        const existing = await this.prisma.$queryRawUnsafe(`SELECT id FROM notificacoes 
       WHERE profissional_id = $1 
         AND titulo = $2 
         AND created_at > NOW() - INTERVAL '24 hours' 
       LIMIT 1`, profId, titulo);
        if (existing && existing.length > 0) {
            return;
        }
        const inserted = await this.prisma.$queryRawUnsafe(`INSERT INTO notificacoes (profissional_id, titulo, mensagem)
       VALUES ($1, $2, $3)
       RETURNING id, titulo, mensagem, lida, created_at`, profId, titulo, mensagem);
        if (inserted && inserted.length > 0) {
            const payload = { ...inserted[0], profissional_id: profId };
            this.gateway.emitToUser(profId, 'notifications-changed', payload);
        }
    }
    async checkCaixaAtrasado(profId) {
        const atrasados = await this.prisma.$queryRawUnsafe(`SELECT id, descricao, data_movimento, valor 
       FROM fluxo_caixa 
       WHERE status = 'pendente' 
         AND data_movimento < CURRENT_DATE - INTERVAL '30 days'
         AND (profissional_id = $1 OR profissional_id IS NULL)`, profId);
        for (const item of atrasados) {
            const dias = Math.floor((new Date().getTime() - new Date(item.data_movimento).getTime()) / (1000 * 3600 * 24));
            const titulo = `Caixa Atrasado: ${item.descricao}`;
            const mensagem = `O lançamento "${item.descricao}" no valor de R$ ${item.valor} está pendente há ${dias} dias.`;
            await this.notify(profId, titulo, mensagem);
        }
    }
    async checkEstoqueBaixo(profId) {
        const baixoEstoque = await this.prisma.$queryRawUnsafe(`SELECT id, nome, quantidade, estoque_minimo 
       FROM estoque_produtos 
       WHERE quantidade < estoque_minimo
         AND (profissional_id = $1 OR profissional_id IS NULL)`, profId);
        for (const item of baixoEstoque) {
            const titulo = `Estoque Baixo: ${item.nome}`;
            const mensagem = `O produto "${item.nome}" atingiu uma quantidade crítica (${item.quantidade} de ${item.estoque_minimo} mínimo).`;
            await this.notify(profId, titulo, mensagem);
        }
    }
    async checkAgendamentoProximo(profId) {
        const proximos = await this.prisma.$queryRawUnsafe(`SELECT a.id, a.data_hora, c.nome as cliente_nome
       FROM agendamentos a
       LEFT JOIN clientes c ON a.cliente_id = c.id
       WHERE a.status IN ('agendado', 'confirmado')
         AND a.data_hora BETWEEN NOW() AND NOW() + INTERVAL '2 hours'
         AND (a.profissional_id = $1 OR a.profissional_id IS NULL)`, profId);
        for (const item of proximos) {
            const hora = new Date(item.data_hora).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
            const clienteNome = item.cliente_nome || 'Cliente';
            const titulo = `Atendimento Próximo: ${clienteNome}`;
            const mensagem = `Você tem um agendamento com ${clienteNome} hoje às ${hora}.`;
            await this.notify(profId, titulo, mensagem);
        }
    }
    async checkManutencao(profId) {
        const manutencoes = await this.prisma.$queryRawUnsafe(`SELECT a.id, a.data_hora, c.nome as cliente_nome
       FROM agendamentos a
       LEFT JOIN clientes c ON a.cliente_id = c.id
       WHERE a.status IN ('agendado', 'confirmado')
         AND a.data_hora BETWEEN (CURRENT_DATE + INTERVAL '2 days') AND (CURRENT_DATE + INTERVAL '3 days')
         AND (a.profissional_id = $1 OR a.profissional_id IS NULL)
         AND (a.observacao ILIKE '%manuten%' OR a.tipo_atendimento ILIKE '%manuten%')`, profId);
        for (const item of manutencoes) {
            const clienteNome = item.cliente_nome || 'Cliente';
            const titulo = `Lembrete de Manutenção: ${clienteNome}`;
            const mensagem = `O agendamento de manutenção de ${clienteNome} será daqui a 2 dias (${new Date(item.data_hora).toLocaleDateString('pt-BR')}).`;
            await this.notify(profId, titulo, mensagem);
        }
    }
};
exports.CronService = CronService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_10_MINUTES),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CronService.prototype, "handleCron", null);
exports.CronService = CronService = CronService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        notifications_gateway_1.NotificationsGateway])
], CronService);
//# sourceMappingURL=cron.service.js.map