import { PrismaService } from '../prisma/prisma.service';
export declare class ServicosService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findAll(tenantSlug: string, user?: any): Promise<{
        servicos: any;
    }>;
    toggleServicoAtendo(tenantSlug: string, user: any, servicoId: number): Promise<{
        servico_id: number;
        habilitado_profissional: boolean;
    }>;
    toggleSubservicoAtendo(tenantSlug: string, user: any, subservicoId: number): Promise<{
        subservico_id: number;
        habilitado_profissional: boolean;
    }>;
    create(tenantSlug: string, user: any, dto: any): Promise<{
        servico: any;
    }>;
    update(tenantSlug: string, user: any, id: number, dto: any): Promise<{
        servico: any;
    }>;
    vincularProduto(tenantSlug: string, servicoId: number, dto: any): Promise<{
        vinculo: any;
    }>;
    removerVinculoProduto(tenantSlug: string, servicoId: number, produtoId: number): Promise<{
        message: string;
    }>;
    listarProdutosServico(tenantSlug: string, servicoId: number): Promise<{
        produtos: any;
    }>;
    deleteServico(tenantSlug: string, user: any, id: number): Promise<{
        message: string;
    }>;
    createSubservico(tenantSlug: string, user: any, servicoId: number, dto: any): Promise<{
        subservico: any;
    }>;
    updateSubservico(tenantSlug: string, user: any, subservicoId: number, dto: any): Promise<{
        subservico: any;
    }>;
    deleteSubservico(tenantSlug: string, user: any, subservicoId: number): Promise<{
        message: string;
    }>;
    vincularProdutoSubservico(tenantSlug: string, subservicoId: number, dto: any): Promise<{
        vinculo: any;
    }>;
    removerVinculoProdutoSubservico(tenantSlug: string, subservicoId: number, produtoId: number): Promise<{
        message: string;
    }>;
    listarProdutosSubservico(tenantSlug: string, subservicoId: number): Promise<{
        produtos: any;
    }>;
}
