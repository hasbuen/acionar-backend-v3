import { PrismaService } from '../prisma/prisma.service';
export declare class WhatsappService {
    private readonly prisma;
    private readonly logger;
    private readonly apiUrl;
    private readonly apiKey;
    constructor(prisma: PrismaService);
    private getHeaders;
    getStatus(tenantSlug: string): Promise<{
        connected: boolean;
        state: any;
        qrcode: string;
        error?: undefined;
    } | {
        connected: boolean;
        state: string;
        qrcode: any;
        error: any;
    }>;
    connect(tenantSlug: string): Promise<{
        qrcode: any;
        state: string;
        connected: boolean;
    } | {
        qrcode: any;
        state: string;
        connected?: undefined;
    }>;
    disconnect(tenantSlug: string): Promise<{
        success: boolean;
        message: string;
    }>;
    sendTextMessage(tenantSlug: string, phone: string, text: string): Promise<{
        success: boolean;
        status: number;
        error: any;
        message?: undefined;
        data?: undefined;
    } | {
        success: boolean;
        message: string;
        data: any;
        status?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        status?: undefined;
        message?: undefined;
        data?: undefined;
    }>;
}
