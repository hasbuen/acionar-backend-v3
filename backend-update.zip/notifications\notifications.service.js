"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const webpush = require("web-push");
let NotificationsService = class NotificationsService {
    constructor(prisma) {
        this.prisma = prisma;
        if (process.env.VAPID_SUBJECT && process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
            webpush.setVapidDetails(process.env.VAPID_SUBJECT, process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
        }
    }
    async getPublicKey() {
        return { publicKey: process.env.VAPID_PUBLIC_KEY || '' };
    }
    async subscribe(tenantSlug, user, dto) {
        const { endpoint, p256dh, auth, user_agent, plataforma } = dto;
        if (!endpoint)
            throw new common_1.BadRequestException('Endpoint is required.');
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            await this.prisma.$executeRawUnsafe(`INSERT INTO push_subscriptions (endpoint, p256dh, auth, profissional_id, user_agent, plataforma, ativo, atualizado_em)
         VALUES ($1, $2, $3, $4, $5, $6, true, NOW())
         ON CONFLICT (endpoint) 
         DO UPDATE SET p256dh = EXCLUDED.p256dh, auth = EXCLUDED.auth, profissional_id = EXCLUDED.profissional_id, ativo = true, atualizado_em = NOW()`, endpoint, p256dh, auth, user.profissional_id, user_agent || null, plataforma || null);
            return { message: 'Subscribed to push notifications.' };
        });
    }
    async unsubscribe(tenantSlug, dto) {
        const { endpoint } = dto;
        if (!endpoint)
            throw new common_1.BadRequestException('Endpoint is required.');
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            await this.prisma.$executeRawUnsafe('UPDATE push_subscriptions SET ativo = false, atualizado_em = NOW() WHERE endpoint = $1', endpoint);
            return { message: 'Unsubscribed from push notifications.' };
        });
    }
    async sendAppointmentPush(tenantSlug, appointmentId) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const apptRows = await this.prisma.$queryRawUnsafe(`SELECT a.*, c.nome as cliente_nome, c.whatsapp as cliente_whatsapp, s.nome as servico_nome
         FROM agendamentos a
         LEFT JOIN clientes c ON a.cliente_id = c.id
         LEFT JOIN servicos s ON a.servico_id = s.id
         WHERE a.id = $1`, appointmentId);
            if (!apptRows || apptRows.length === 0)
                return;
            const appointment = apptRows[0];
            let nomeCliente = appointment.cliente_nome;
            let whatsappCliente = appointment.cliente_whatsapp;
            if (appointment.observacao) {
                try {
                    const obs = typeof appointment.observacao === 'object' ? appointment.observacao : JSON.parse(appointment.observacao);
                    if (obs && obs.temp_cliente_nome) {
                        nomeCliente = obs.temp_cliente_nome;
                    }
                    if (obs && obs.temp_cliente_whatsapp) {
                        whatsappCliente = obs.temp_cliente_whatsapp;
                    }
                }
                catch (e) { }
            }
            const cleanPhone = whatsappCliente ? String(whatsappCliente).replace(/\D/g, '') : '';
            const phoneFormatted = cleanPhone ? (cleanPhone.length >= 10 ? `(${cleanPhone.slice(-11, -8)}) ${cleanPhone.slice(-8, -4)}-${cleanPhone.slice(-4)}` : cleanPhone) : 'Não informado';
            const dateFormatted = new Date(appointment.data_hora).toLocaleDateString('pt-BR');
            const timeFormatted = new Date(appointment.data_hora).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
            const dataHoraFormatted = `${dateFormatted} às ${timeFormatted}`;
            const isDomicilio = (appointment.tipo_atendimento || '').toLowerCase() === 'domicilio' || (appointment.tipo_atendimento || '').toLowerCase() === 'externo' || !!appointment.endereco_externo;
            let enderecoTexto = '';
            if (appointment.endereco_externo) {
                if (typeof appointment.endereco_externo === 'object') {
                    const endObj = appointment.endereco_externo;
                    enderecoTexto = `${endObj.rua || ''}, ${endObj.numero || ''} ${endObj.bairro ? `— ${endObj.bairro}` : ''}`;
                }
                else {
                    try {
                        const parsed = JSON.parse(appointment.endereco_externo);
                        if (typeof parsed === 'object' && parsed !== null) {
                            enderecoTexto = `${parsed.rua || ''}, ${parsed.numero || ''} ${parsed.bairro ? `— ${parsed.bairro}` : ''}`;
                        }
                        else {
                            enderecoTexto = String(appointment.endereco_externo);
                        }
                    }
                    catch (e) {
                        enderecoTexto = String(appointment.endereco_externo);
                    }
                }
            }
            const notifTitle = isDomicilio ? `🏠 Agendamento DOMICILIAR: ${nomeCliente || 'Cliente'}` : `Novo agendamento: ${nomeCliente || 'Cliente'}`;
            const bodyLines = [];
            if (isDomicilio) {
                bodyLines.push(`🏠 Local: ATENDIMENTO A DOMICÍLIO`);
                if (enderecoTexto) {
                    bodyLines.push(`📍 Endereço: ${enderecoTexto}`);
                }
            }
            bodyLines.push(`Serviço: ${appointment.servico_nome || 'Serviço'}`);
            bodyLines.push(`Data: ${dataHoraFormatted}`);
            bodyLines.push(`📱 WhatsApp: ${phoneFormatted}`);
            let subscriptions = [];
            try {
                if (appointment.profissional_id) {
                    subscriptions = await this.prisma.$queryRawUnsafe(`SELECT * FROM push_subscriptions 
             WHERE (profissional_id = $1 OR profissional_id IS NULL) 
               AND (ativo = true OR ativo IS NULL)`, appointment.profissional_id);
                }
                else if (isDomicilio) {
                    subscriptions = await this.prisma.$queryRawUnsafe(`SELECT DISTINCT s.* 
             FROM push_subscriptions s
             LEFT JOIN profissionais p ON s.profissional_id = p.id
             WHERE (s.ativo = true OR s.ativo IS NULL)
               AND (p.aceita_atendimento_externo = true OR s.profissional_id IS NULL)`);
                    if (!subscriptions || subscriptions.length === 0) {
                        subscriptions = await this.prisma.$queryRawUnsafe('SELECT * FROM push_subscriptions WHERE (ativo = true OR ativo IS NULL)');
                    }
                }
                else {
                    subscriptions = await this.prisma.$queryRawUnsafe('SELECT * FROM push_subscriptions WHERE (ativo = true OR ativo IS NULL)');
                }
            }
            catch (eSub) {
                console.error('[PUSH SUB FETCH ERROR]', eSub);
            }
            if (subscriptions.length === 0)
                return;
            const payload = JSON.stringify({
                title: notifTitle,
                body: bodyLines.join('\n'),
                url: '/agenda',
                icon: '/icon-192.png',
                badge: '/icon-192.png',
                data: {
                    url: '/agenda',
                    tenantSlug,
                    agendamentoId: appointment.id,
                    clienteNome: nomeCliente || 'Cliente',
                    servicoNome: appointment.servico_nome || 'Serviço',
                    whatsapp: cleanPhone ? (cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`) : '',
                    dataHoraFormatted,
                    confirmUrl: `/api/public/tenant/${tenantSlug}/agendamentos/${appointment.id}/confirmar-rapido?cliente_nome=${encodeURIComponent(nomeCliente || 'Cliente')}&whatsapp=${encodeURIComponent(cleanPhone || '')}`
                },
                actions: [
                    { action: 'open_agenda', title: '📅 Ver na Agenda' }
                ]
            });
            for (const sub of subscriptions) {
                if (!sub.endpoint || !sub.p256dh || !sub.auth)
                    continue;
                try {
                    await webpush.sendNotification({
                        endpoint: sub.endpoint,
                        keys: { p256dh: sub.p256dh, auth: sub.auth }
                    }, payload);
                }
                catch (error) {
                    console.error('Failed to send web push notification:', error);
                    const statusCode = error.response?.statusCode || 0;
                    if ([401, 403, 404, 410].includes(statusCode)) {
                        await this.prisma.$executeRawUnsafe('UPDATE push_subscriptions SET ativo = false WHERE id = $1', sub.id);
                    }
                }
            }
        });
    }
    async findAll(tenantSlug, user) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const notifications = await this.prisma.$queryRawUnsafe('SELECT id, titulo, mensagem, lida, created_at FROM notificacoes WHERE profissional_id = $1 ORDER BY created_at DESC LIMIT 50', user.profissional_id);
            return { notifications };
        });
    }
    async markAsRead(tenantSlug, id, user) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const result = await this.prisma.$queryRawUnsafe('UPDATE notificacoes SET lida = true WHERE id = $1 AND profissional_id = $2 RETURNING *', id, user.profissional_id);
            return { notification: result[0] };
        });
    }
    async clearAll(tenantSlug, user) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            await this.prisma.$queryRawUnsafe('DELETE FROM notificacoes WHERE profissional_id = $1', user.profissional_id);
            return { message: 'Notifications cleared.' };
        });
    }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], NotificationsService);
//# sourceMappingURL=notifications.service.js.map