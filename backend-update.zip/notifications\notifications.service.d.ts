import { PrismaService } from '../prisma/prisma.service';
export declare class NotificationsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getPublicKey(): Promise<{
        publicKey: string;
    }>;
    subscribe(tenantSlug: string, user: any, dto: any): Promise<{
        message: string;
    }>;
    unsubscribe(tenantSlug: string, dto: any): Promise<{
        message: string;
    }>;
    sendAppointmentPush(tenantSlug: string, appointmentId: number): Promise<void>;
    findAll(tenantSlug: string, user: any): Promise<{
        notifications: any;
    }>;
    markAsRead(tenantSlug: string, id: number, user: any): Promise<{
        notification: any;
    }>;
    clearAll(tenantSlug: string, user: any): Promise<{
        message: string;
    }>;
}
