"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgendamentosModule = void 0;
const common_1 = require("@nestjs/common");
const agendamentos_service_1 = require("./agendamentos.service");
const agendamentos_controller_1 = require("./agendamentos.controller");
const auth_module_1 = require("../auth/auth.module");
const notifications_module_1 = require("../notifications/notifications.module");
const whatsapp_module_1 = require("../whatsapp/whatsapp.module");
let AgendamentosModule = class AgendamentosModule {
};
exports.AgendamentosModule = AgendamentosModule;
exports.AgendamentosModule = AgendamentosModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, notifications_module_1.NotificationsModule, whatsapp_module_1.WhatsappModule],
        providers: [agendamentos_service_1.AgendamentosService],
        controllers: [agendamentos_controller_1.AgendamentosController],
    })
], AgendamentosModule);
//# sourceMappingURL=agendamentos.module.js.map