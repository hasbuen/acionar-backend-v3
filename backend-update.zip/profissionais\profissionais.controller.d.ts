import { ProfissionaisService } from './profissionais.service';
export declare class ProfissionaisController {
    private readonly profissionaisService;
    constructor(profissionaisService: ProfissionaisService);
    findAll(req: any): Promise<{
        profissionais: any;
    }>;
    create(req: any, body: any): Promise<{
        profissional: any;
    }>;
    update(req: any, id: string, body: any): Promise<{
        profissional: any;
    }>;
    remove(req: any, id: string): Promise<{
        message: string;
    }>;
}
