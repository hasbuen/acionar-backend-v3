"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var WhatsappService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhatsappService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let WhatsappService = WhatsappService_1 = class WhatsappService {
    constructor(prisma) {
        this.prisma = prisma;
        this.logger = new common_1.Logger(WhatsappService_1.name);
        this.apiUrl = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
        this.apiKey = process.env.EVOLUTION_API_KEY || 'acionar_token_v3_secure_evolution';
    }
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'apikey': this.apiKey,
        };
    }
    async getStatus(tenantSlug) {
        const instanceName = `tenant_${tenantSlug}`;
        try {
            const response = await fetch(`${this.apiUrl}/instance/connectionState/${instanceName}`, {
                method: 'GET',
                headers: this.getHeaders(),
            });
            if (!response.ok) {
                return { connected: false, state: 'close', qrcode: null };
            }
            const data = await response.json();
            const state = data?.instance?.state || 'close';
            let qrcode = null;
            if (state === 'connecting') {
                try {
                    const connectResponse = await fetch(`${this.apiUrl}/instance/connect/${instanceName}`, {
                        method: 'GET',
                        headers: this.getHeaders(),
                    });
                    const connectData = await connectResponse.json();
                    qrcode = connectData?.qrcode?.base64 || connectData?.base64 || null;
                }
                catch (e) {
                }
            }
            return {
                connected: state === 'open',
                state,
                qrcode,
            };
        }
        catch (error) {
            this.logger.error(`Erro ao obter status do WhatsApp para ${instanceName}:`, error);
            return { connected: false, state: 'close', qrcode: null, error: error.message };
        }
    }
    async connect(tenantSlug) {
        const instanceName = `tenant_${tenantSlug}`;
        try {
            const currentStatus = await this.getStatus(tenantSlug);
            if (currentStatus.connected) {
                return {
                    qrcode: null,
                    state: 'open',
                    connected: true,
                };
            }
            try {
                await fetch(`${this.apiUrl}/instance/delete/${instanceName}`, {
                    method: 'DELETE',
                    headers: this.getHeaders(),
                });
            }
            catch (e) {
            }
            const createResponse = await fetch(`${this.apiUrl}/instance/create`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({
                    instanceName,
                    qrcode: true,
                    integration: 'WHATSAPP-BAILEYS',
                }),
            });
            const createData = await createResponse.json();
            const createQr = createData?.qrcode?.base64 || createData?.base64;
            if (createQr) {
                return {
                    qrcode: createQr,
                    state: 'connecting',
                };
            }
            const connectResponse = await fetch(`${this.apiUrl}/instance/connect/${instanceName}`, {
                method: 'GET',
                headers: this.getHeaders(),
            });
            const connectData = await connectResponse.json();
            const connectQr = connectData?.qrcode?.base64 || connectData?.base64;
            if (connectQr) {
                return {
                    qrcode: connectQr,
                    state: 'connecting',
                };
            }
            return {
                qrcode: null,
                state: 'close',
                connected: false,
            };
        }
        catch (error) {
            this.logger.error(`Erro ao conectar WhatsApp para ${instanceName}:`, error);
            throw new common_1.BadRequestException(`Erro ao conectar ao WhatsApp: ${error.message}`);
        }
    }
    async disconnect(tenantSlug) {
        const instanceName = `tenant_${tenantSlug}`;
        try {
            await fetch(`${this.apiUrl}/instance/logout/${instanceName}`, {
                method: 'DELETE',
                headers: this.getHeaders(),
            });
            await fetch(`${this.apiUrl}/instance/delete/${instanceName}`, {
                method: 'DELETE',
                headers: this.getHeaders(),
            });
            await this.prisma.ensureTenantSchema(tenantSlug);
            await this.prisma.runInTenantSchema(tenantSlug, async () => {
                const settings = { connected: false, session_name: instanceName, updated_at: new Date() };
                await this.prisma.$executeRawUnsafe('INSERT INTO configuracoes (chave, valor, updated_at) VALUES ($1, $2::jsonb, NOW()) ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor, updated_at = NOW()', 'whatsapp', JSON.stringify(settings));
            });
            return { success: true, message: 'WhatsApp desconectado com sucesso.' };
        }
        catch (error) {
            this.logger.error(`Erro ao desconectar WhatsApp para ${instanceName}:`, error);
            throw new common_1.BadRequestException(`Erro ao desconectar WhatsApp: ${error.message}`);
        }
    }
    async sendTextMessage(tenantSlug, phone, text) {
        const instanceName = `tenant_${tenantSlug}`;
        const cleanPhone = String(phone).replace(/\D/g, '');
        const phoneWithCountry = cleanPhone.length <= 11 ? `55${cleanPhone}` : cleanPhone;
        try {
            const response = await fetch(`${this.apiUrl}/message/sendText/${instanceName}`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({
                    number: phoneWithCountry,
                    text,
                }),
            });
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                this.logger.error(`Erro ao enviar mensagem de WhatsApp (${response.status}):`, errorData);
                return { success: false, status: response.status, error: errorData };
            }
            const data = await response.json();
            return { success: true, message: 'Mensagem enviada com sucesso.', data };
        }
        catch (error) {
            this.logger.error(`Erro ao disparar mensagem para ${cleanPhone} via ${instanceName}:`, error);
            return { success: false, error: error.message };
        }
    }
};
exports.WhatsappService = WhatsappService;
exports.WhatsappService = WhatsappService = WhatsappService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WhatsappService);
//# sourceMappingURL=whatsapp.service.js.map