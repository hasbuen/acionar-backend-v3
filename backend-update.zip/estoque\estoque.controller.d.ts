import { EstoqueService } from './estoque.service';
export declare class EstoqueController {
    private readonly estoqueService;
    constructor(estoqueService: EstoqueService);
    findProdutos(req: any): Promise<{
        produtos: any;
        resumo: {
            total_produtos: any;
            valor_total_estoque: number;
            produtos_em_alerta: number;
            estado_geral: string;
        };
    }>;
    createProduto(req: any, body: any): Promise<{
        produto: any;
    }>;
    findMovimentacoes(req: any, query: any): Promise<{
        movimentacoes: any;
    }>;
    createMovimentacao(req: any, body: any): Promise<{
        movimentacao: any;
        nova_quantidade: any;
    }>;
    transferProduto(req: any, body: any): Promise<{
        message: string;
        nova_quantidade: number;
    }>;
    findAlerts(req: any): Promise<{
        alertas: any;
        total_alertas: any;
        urgencia: string;
    }>;
    deleteProduto(req: any, id: string): Promise<{
        message: string;
    }>;
}
