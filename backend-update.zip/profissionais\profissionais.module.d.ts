export declare class ProfissionaisModule {
}
