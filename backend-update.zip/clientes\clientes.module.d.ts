export declare class ClientesModule {
}
