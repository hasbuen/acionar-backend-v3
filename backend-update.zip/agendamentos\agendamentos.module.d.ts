export declare class AgendamentosModule {
}
