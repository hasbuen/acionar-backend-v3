import { WhatsappService } from './whatsapp.service';
export declare class WhatsappController {
    private readonly whatsappService;
    constructor(whatsappService: WhatsappService);
    getStatus(req: any): Promise<{
        connected: boolean;
        state: any;
        qrcode: string;
        error?: undefined;
    } | {
        connected: boolean;
        state: string;
        qrcode: any;
        error: any;
    }>;
    connect(req: any): Promise<{
        qrcode: any;
        state: string;
        connected: boolean;
    } | {
        qrcode: any;
        state: string;
        connected?: undefined;
    }>;
    disconnect(req: any): Promise<{
        success: boolean;
        message: string;
    }>;
}
