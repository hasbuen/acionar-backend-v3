export declare class EstoqueModule {
}
