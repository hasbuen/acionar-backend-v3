export declare class CaixaModule {
}
