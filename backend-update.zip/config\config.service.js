"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const fs = require("fs");
const path = require("path");
let ConfigService = class ConfigService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getPaymentConfig(tenantSlug) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const rows = await this.prisma.$queryRawUnsafe('SELECT valor FROM configuracoes WHERE chave = $1', 'pagamentos');
            const settings = rows[0] || { asaas_enabled: false, asaas_environment: 'sandbox', pix_key: '', pix_key_type: 'aleatoria' };
            return { settings };
        });
    }
    async updatePaymentConfig(tenantSlug, dto) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const settings = {
                asaas_enabled: Boolean(dto.asaas_enabled),
                asaas_environment: dto.asaas_environment === 'production' ? 'production' : 'sandbox',
                pix_key: String(dto.pix_key || '').trim(),
                pix_key_type: String(dto.pix_key_type || 'aleatoria'),
            };
            await this.prisma.$executeRawUnsafe('INSERT INTO configuracoes (chave, valor, updated_at) VALUES ($1, $2::jsonb, NOW()) ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor, updated_at = NOW()', 'pagamentos', JSON.stringify(settings));
            return { message: 'Payment configuration saved.', settings };
        });
    }
    async getPublicScheduleConfig(tenantSlug) {
        const tenant = await this.prisma.tenant.findUnique({
            where: { slug: tenantSlug },
            select: {
                slug: true,
                subdominio: true,
                nome_empresa: true,
                foto_url: true,
                cor_primaria: true,
                cor_destaque: true,
                cor_fundo: true,
                cor_texto_principal: true,
                cor_texto_secundario: true,
                agenda_publica_ativa: true,
            },
        });
        if (!tenant)
            throw new common_1.NotFoundException('Tenant not found.');
        return {
            settings: {
                ...tenant,
                slug: tenant.subdominio || tenant.slug,
            }
        };
    }
    async updatePublicScheduleConfig(tenantSlug, dto) {
        const { agenda_publica_ativa, foto_url, cor_primaria, cor_destaque, cor_fundo, cor_texto_principal, cor_texto_secundario, novo_slug, nome_empresa } = dto;
        const currentTenant = await this.prisma.tenant.findUnique({ where: { slug: tenantSlug } });
        if (!currentTenant)
            throw new common_1.NotFoundException('Tenant not found.');
        const isAtiva = agenda_publica_ativa !== undefined ? Boolean(agenda_publica_ativa) : currentTenant.agenda_publica_ativa;
        if (nome_empresa !== undefined && nome_empresa !== currentTenant.nome_empresa) {
            if (!isAtiva) {
                throw new common_1.ConflictException('Não é possível alterar o nome da empresa com a agenda pública desativada.');
            }
        }
        let targetSubdomain = null;
        if (novo_slug) {
            const cleanSub = novo_slug.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_');
            if (cleanSub !== tenantSlug) {
                const existing = await this.prisma.tenant.findFirst({
                    where: {
                        OR: [
                            { subdominio: cleanSub },
                            { slug: cleanSub }
                        ],
                        slug: { not: tenantSlug }
                    }
                });
                if (existing) {
                    throw new common_1.ConflictException(`Slug '${cleanSub}' is already taken.`);
                }
                targetSubdomain = cleanSub;
            }
        }
        const updated = await this.prisma.tenant.update({
            where: { slug: tenantSlug },
            data: {
                subdominio: targetSubdomain,
                nome_empresa: nome_empresa !== undefined && isAtiva ? String(nome_empresa).trim() : undefined,
                agenda_publica_ativa: agenda_publica_ativa !== undefined ? agenda_publica_ativa : undefined,
                foto_url: foto_url !== undefined ? foto_url : undefined,
                cor_primaria: cor_primaria || undefined,
                cor_destaque: cor_destaque || undefined,
                cor_fundo: cor_fundo || undefined,
                cor_texto_principal: cor_texto_principal || undefined,
                cor_texto_secundario: cor_texto_secundario || undefined,
            },
            select: {
                slug: true,
                subdominio: true,
                nome_empresa: true,
                foto_url: true,
                cor_primaria: true,
                cor_destaque: true,
                cor_fundo: true,
                cor_texto_principal: true,
                cor_texto_secundario: true,
                agenda_publica_ativa: true,
            },
        });
        return {
            message: 'Configuration updated successfully.',
            settings: {
                ...updated,
                slug: updated.subdominio || updated.slug,
            },
        };
    }
    async getMessageConfig(tenantSlug) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const rows = await this.prisma.$queryRawUnsafe('SELECT valor FROM configuracoes WHERE chave = $1', 'mensagens');
            const defaultSettings = {
                endereco: 'Rua da amizade 515 bairro: 14 de novembro',
                template_confirmacao: `📍 *Endereço*: {endereco}\n\nPor gentileza, informe se concorda com este horário ou se prefere realizar alguma alteração.\n\n📌 *Lembrete importante*: Pedimos a gentileza de chegar com **15 minutos de antecedência**.\n\nAgradecemos a preferência e aguardamos você!😊`,
                template_manutencao: `Olá, *{cliente}*! 👋\n\nPassando para lembrar que sua *MANUTENÇÃO PERIÓDICA* de *{servico}* está agendada para o dia *{data}* às *{hora}*.\n\n📍 *Endereço*: {endereco}`,
            };
            const settings = rows[0]?.valor || defaultSettings;
            return { settings };
        });
    }
    async updateMessageConfig(tenantSlug, dto) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const settings = {
                endereco: dto.endereco || '',
                template_confirmacao: dto.template_confirmacao || '',
                template_manutencao: dto.template_manutencao || '',
            };
            await this.prisma.$executeRawUnsafe('INSERT INTO configuracoes (chave, valor, updated_at) VALUES ($1, $2::jsonb, NOW()) ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor, updated_at = NOW()', 'mensagens', JSON.stringify(settings));
            return { message: 'Configurações de mensagens salvas com sucesso.', settings };
        });
    }
    async getBotFlow(tenantSlug) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const rows = await this.prisma.$queryRawUnsafe('SELECT valor FROM configuracoes WHERE chave = $1', 'bot_flow');
            const defaultFlow = {
                nodes: [
                    {
                        id: 'node-trigger',
                        type: 'trigger',
                        title: 'Novo Agendamento Criado',
                        description: 'Disparado quando o cliente solicita um agendamento no portal público',
                        config: { event: 'booking_created' }
                    },
                    {
                        id: 'node-msg-1',
                        type: 'send_message',
                        title: 'Enviar Confirmação',
                        config: {
                            text: 'Olá, *{cliente}*! 👋\n\nRecebemos sua solicitação para *{servico}* no dia *{data}* às *{hora}* com *{profissional}*.\n\n📍 *Endereço*: {endereco}\n\nPor favor, responda com uma das opções abaixo:\n\n1️⃣ Digite *1* para **Confirmar**\n2️⃣ Digite *2* para **Cancelar**'
                        }
                    },
                    {
                        id: 'node-options',
                        type: 'options',
                        title: 'Aguardar Resposta do Cliente',
                        config: {
                            options: [
                                { key: '1', label: 'Confirmar Agendamento', nextNodeId: 'node-action-confirm' },
                                { key: '2', label: 'Cancelar Agendamento', nextNodeId: 'node-action-cancel' }
                            ],
                            fallbackText: 'Desculpe, não entendi. Digite *1* para Confirmar ou *2* para Cancelar o agendamento.'
                        }
                    },
                    {
                        id: 'node-action-confirm',
                        type: 'action',
                        title: 'Confirmar Agendamento',
                        config: {
                            actionType: 'confirm_booking',
                            responseText: '✅ *Agendamento Confirmado!* Muito obrigado, estamos te aguardando no horário agendado! 😊'
                        }
                    },
                    {
                        id: 'node-action-cancel',
                        type: 'action',
                        title: 'Cancelar Agendamento',
                        config: {
                            actionType: 'cancel_booking',
                            responseText: '❌ *Agendamento Cancelado.* Se precisar remarcar futuramente, ficamos à disposição!'
                        }
                    }
                ]
            };
            const flow = rows[0]?.valor || defaultFlow;
            return { flow };
        });
    }
    async updateBotFlow(tenantSlug, flowData) {
        await this.prisma.ensureTenantSchema(tenantSlug);
        return this.prisma.runInTenantSchema(tenantSlug, async () => {
            const flow = flowData.flow || flowData;
            await this.prisma.$executeRawUnsafe('INSERT INTO configuracoes (chave, valor, updated_at) VALUES ($1, $2::jsonb, NOW()) ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor, updated_at = NOW()', 'bot_flow', JSON.stringify(flow));
            return { message: 'Fluxo do Chatbot salvo com sucesso.', flow };
        });
    }
    getUploadsDir() {
        if (process.env.UPLOADS_DIR)
            return process.env.UPLOADS_DIR;
        if (fs.existsSync('/var/www/acionar-v3/uploads'))
            return '/var/www/acionar-v3/uploads';
        return path.join(process.cwd(), 'uploads');
    }
    async uploadLogo(tenantSlug, imageBase64) {
        const cleanSlug = tenantSlug.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_');
        const uploadsDir = this.getUploadsDir();
        if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
        }
        const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
        let buffer;
        let ext = 'png';
        if (matches && matches.length === 3) {
            ext = matches[1].split('/')[1] || 'png';
            buffer = Buffer.from(matches[2], 'base64');
        }
        else {
            buffer = Buffer.from(imageBase64, 'base64');
        }
        const fileKey = `logo_${cleanSlug}_${Date.now()}.${ext}`;
        const filePath = path.join(uploadsDir, fileKey);
        fs.writeFileSync(filePath, buffer);
        const publicHost = process.env.PUBLIC_HOST;
        const fotoUrl = publicHost ? `${publicHost}/uploads/${fileKey}` : `/uploads/${fileKey}`;
        const tenant = await this.prisma.tenant.update({
            where: { slug: cleanSlug },
            data: { foto_url: fotoUrl },
        });
        return {
            message: 'Logo enviado com sucesso.',
            foto_url: fotoUrl,
            tenant,
        };
    }
    async uploadImage(tenantSlug, type, imageBase64) {
        if (!['servicos', 'subservicos', 'produtos'].includes(type)) {
            throw new common_1.BadRequestException('Tipo inválido.');
        }
        const cleanSlug = tenantSlug.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_');
        const uploadsDir = this.getUploadsDir();
        const targetDir = path.join(uploadsDir, type);
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
        let buffer;
        let ext = 'png';
        if (matches && matches.length === 3) {
            ext = matches[1].split('/')[1] || 'png';
            buffer = Buffer.from(matches[2], 'base64');
        }
        else {
            buffer = Buffer.from(imageBase64, 'base64');
        }
        const fileKey = `${type.slice(0, -1)}_${cleanSlug}_${Date.now()}.${ext}`;
        const filePath = path.join(targetDir, fileKey);
        fs.writeFileSync(filePath, buffer);
        const publicHost = process.env.PUBLIC_HOST;
        const fotoUrl = publicHost ? `${publicHost}/uploads/${type}/${fileKey}` : `/uploads/${type}/${fileKey}`;
        return {
            message: 'Foto enviada com sucesso.',
            foto_url: fotoUrl,
        };
    }
};
exports.ConfigService = ConfigService;
exports.ConfigService = ConfigService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ConfigService);
//# sourceMappingURL=config.service.js.map