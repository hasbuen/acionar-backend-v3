import { NotificationsService } from './notifications.service';
export declare class NotificationsController {
    private readonly notificationsService;
    constructor(notificationsService: NotificationsService);
    getPublicKey(): Promise<{
        publicKey: string;
    }>;
    subscribe(req: any, body: any): Promise<{
        message: string;
    }>;
    unsubscribe(req: any, body: any): Promise<{
        message: string;
    }>;
    findAll(req: any): Promise<{
        notifications: any;
    }>;
    markAsRead(req: any, id: string): Promise<{
        notification: any;
    }>;
    clearAll(req: any): Promise<{
        message: string;
    }>;
}
