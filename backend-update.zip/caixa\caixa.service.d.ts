import { PrismaService } from '../prisma/prisma.service';
export declare class CaixaService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findAll(tenantSlug: string, user: any, query: any): Promise<{
        movimentacoes: any[];
        resumo: {
            totalEntradas: number;
            totalAReceber: number;
            totalReceber: number;
            totalSaidas: number;
            totalSaidasPendente: number;
            saldo: number;
            qtdPendentes: number;
            qtdRecebidos: number;
            byFormaPagamento: Record<string, number>;
            evolucao: {
                date: string;
                entradas: number;
                saidas: number;
            }[];
        };
    }>;
    create(tenantSlug: string, user: any, dto: any): Promise<{
        movimentacao: any;
        totalCriados: number;
    }>;
    baixar(tenantSlug: string, user: any, id: string, forma_pagamento: string): Promise<{
        movimentacao: any;
        message: string;
    }>;
    remove(tenantSlug: string, user: any, id: string): Promise<{
        message: string;
    }>;
}
