import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationsGateway } from '../notifications/notifications.gateway';
import { WhatsappService } from '../whatsapp/whatsapp.service';
export declare class PublicService {
    private readonly prisma;
    private readonly notificationsService;
    private readonly notificationsGateway;
    private readonly whatsappService;
    constructor(prisma: PrismaService, notificationsService: NotificationsService, notificationsGateway: NotificationsGateway, whatsappService: WhatsappService);
    getTenantPublicInfo(slug: string): Promise<{
        tenant: {
            slug: string;
            nome_empresa: string;
            foto_url: string;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
        };
    }>;
    getPublicServices(slug: string): Promise<{
        servicos: any;
    }>;
    getPublicProfessionals(slug: string): Promise<{
        profissionais: any;
    }>;
    createPublicAppointment(slug: string, dto: any): Promise<{
        message: string;
        agendamento: any;
    }>;
    handleAsaasWebhook(body: any): Promise<{
        ok: boolean;
        message: string;
        error?: undefined;
    } | {
        ok: boolean;
        message?: undefined;
        error?: undefined;
    } | {
        ok: boolean;
        error: any;
        message?: undefined;
    }>;
    confirmQuickAppointment(slug: string, appointmentId: number, queryParams?: {
        clienteNome?: string;
        whatsapp?: string;
    }): Promise<{
        ok: boolean;
        message: string;
        agendamento?: undefined;
        messageConfig?: undefined;
        clienteNome?: undefined;
        whatsappPhone?: undefined;
        servicoNome?: undefined;
    } | {
        ok: boolean;
        agendamento: any;
        messageConfig: any;
        clienteNome: any;
        whatsappPhone: string;
        servicoNome: string;
        message?: undefined;
    }>;
    handleWhatsappWebhook(payload: any): Promise<{
        ok: boolean;
        appointmentId: any;
        status: string;
        error?: undefined;
    } | {
        ok: boolean;
        skipped: boolean;
        reason: string;
        error?: undefined;
    } | {
        ok: boolean;
        error: string;
        skipped?: undefined;
        reason?: undefined;
    }>;
}
