import { ServicosService } from './servicos.service';
export declare class ServicosController {
    private readonly servicosService;
    constructor(servicosService: ServicosService);
    findAll(req: any): Promise<{
        servicos: any;
    }>;
    toggleServicoAtendo(req: any, id: string): Promise<{
        servico_id: number;
        habilitado_profissional: boolean;
    }>;
    toggleSubservicoAtendo(req: any, subId: string): Promise<{
        subservico_id: number;
        habilitado_profissional: boolean;
    }>;
    create(req: any, body: any): Promise<{
        servico: any;
    }>;
    update(req: any, id: string, body: any): Promise<{
        servico: any;
    }>;
    delete(req: any, id: string): Promise<{
        message: string;
    }>;
    createSubservico(req: any, id: string, body: any): Promise<{
        subservico: any;
    }>;
    updateSubservico(req: any, id: string, subId: string, body: any): Promise<{
        subservico: any;
    }>;
    deleteSubservico(req: any, id: string, subId: string): Promise<{
        message: string;
    }>;
    vincularProduto(req: any, id: string, body: any): Promise<{
        vinculo: any;
    }>;
    removerVinculo(req: any, id: string, produtoId: string): Promise<{
        message: string;
    }>;
    listarProdutos(req: any, id: string): Promise<{
        produtos: any;
    }>;
    vincularProdutoSubservico(req: any, id: string, subId: string, body: any): Promise<{
        vinculo: any;
    }>;
    removerVinculoSubservico(req: any, id: string, subId: string, produtoId: string): Promise<{
        message: string;
    }>;
    listarProdutosSubservico(req: any, id: string, subId: string): Promise<{
        produtos: any;
    }>;
}
