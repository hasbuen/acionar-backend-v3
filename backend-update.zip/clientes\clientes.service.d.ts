import { PrismaService } from '../prisma/prisma.service';
import { NotificationsGateway } from '../notifications/notifications.gateway';
export declare class ClientesService {
    private readonly prisma;
    private readonly notificationsGateway;
    constructor(prisma: PrismaService, notificationsGateway: NotificationsGateway);
    findAll(tenantSlug: string, user?: any): Promise<{
        clientes: any;
    }>;
    create(tenantSlug: string, user: any, dto: any): Promise<{
        cliente: any;
    }>;
    update(tenantSlug: string, id: number, dto: any): Promise<{
        cliente: any;
    }>;
    transferir(tenantSlug: string, id: number, profissionalDestinoId: number, user?: any): Promise<{
        cliente: any;
        message: string;
    }>;
    remove(tenantSlug: string, user: any, id: number): Promise<{
        message: string;
    }>;
}
