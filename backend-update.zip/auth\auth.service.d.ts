import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
export declare class AuthService {
    private readonly prisma;
    private readonly jwtService;
    constructor(prisma: PrismaService, jwtService: JwtService);
    registerTenant(dto: any): Promise<{
        message: string;
        token: string;
        tenant: {
            slug: string;
            subdominio: string | null;
            nome_empresa: string;
            email_proprietario: string;
            telefone: string | null;
            senha_hash: string;
            status: string;
            foto_url: string | null;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
            created_at: Date;
            updated_at: Date;
            id: number;
        };
        user: any;
    }>;
    login(dto: any): Promise<{
        token: string;
        tenant: {
            slug: string;
            subdominio: string | null;
            nome_empresa: string;
            email_proprietario: string;
            telefone: string | null;
            senha_hash: string;
            status: string;
            foto_url: string | null;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
            created_at: Date;
            updated_at: Date;
            id: number;
        };
        user: any;
    }>;
    me(payload: any): Promise<{
        tenant: {
            slug: string;
            subdominio: string | null;
            nome_empresa: string;
            email_proprietario: string;
            telefone: string | null;
            senha_hash: string;
            status: string;
            foto_url: string | null;
            cor_primaria: string;
            cor_destaque: string;
            cor_fundo: string;
            cor_texto_principal: string;
            cor_texto_secundario: string;
            agenda_publica_ativa: boolean;
            created_at: Date;
            updated_at: Date;
            id: number;
        };
        user: any;
    }>;
}
