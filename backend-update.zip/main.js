"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = require("dotenv");
dotenv.config();
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const express_1 = require("express");
const express = require("express");
const path = require("path");
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    const fs = require('fs');
    const uploadsDir = process.env.UPLOADS_DIR || (fs.existsSync('/var/www/acionar-v3/uploads') ? '/var/www/acionar-v3/uploads' : path.join(process.cwd(), 'uploads'));
    app.use('/uploads', express.static(uploadsDir));
    app.use((0, express_1.json)({ limit: '10mb' }));
    app.use((0, express_1.urlencoded)({ limit: '10mb', extended: true }));
    app.enableCors({
        origin: true,
        credentials: true,
    });
    const port = process.env.PORT || 3001;
    await app.listen(port, '0.0.0.0');
    console.log(`[ACIONAR V3 NESTJS] Backend API running on port ${port}`);
}
bootstrap();
//# sourceMappingURL=main.js.map