import { CaixaService } from './caixa.service';
export declare class CaixaController {
    private readonly caixaService;
    constructor(caixaService: CaixaService);
    findAll(req: any, query: any): Promise<{
        movimentacoes: any[];
        resumo: {
            totalEntradas: number;
            totalAReceber: number;
            totalReceber: number;
            totalSaidas: number;
            totalSaidasPendente: number;
            saldo: number;
            qtdPendentes: number;
            qtdRecebidos: number;
            byFormaPagamento: Record<string, number>;
            evolucao: {
                date: string;
                entradas: number;
                saidas: number;
            }[];
        };
    }>;
    create(req: any, body: any): Promise<{
        movimentacao: any;
        totalCriados: number;
    }>;
    baixar(req: any, id: string, body: any): Promise<{
        movimentacao: any;
        message: string;
    }>;
    remove(req: any, id: string): Promise<{
        message: string;
    }>;
}
