import { PrismaService } from '../prisma/prisma.service';
export declare class ProfissionaisService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findAll(tenantSlug: string): Promise<{
        profissionais: any;
    }>;
    create(tenantSlug: string, dto: any): Promise<{
        profissional: any;
    }>;
    update(tenantSlug: string, id: number, dto: any): Promise<{
        profissional: any;
    }>;
    remove(tenantSlug: string, id: number): Promise<{
        message: string;
    }>;
}
