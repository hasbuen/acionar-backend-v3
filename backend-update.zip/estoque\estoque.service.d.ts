import { PrismaService } from '../prisma/prisma.service';
import { NotificationsGateway } from '../notifications/notifications.gateway';
export declare class EstoqueService {
    private readonly prisma;
    private readonly notificationsGateway;
    constructor(prisma: PrismaService, notificationsGateway: NotificationsGateway);
    findProdutos(tenantSlug: string, user?: any): Promise<{
        produtos: any;
        resumo: {
            total_produtos: any;
            valor_total_estoque: number;
            produtos_em_alerta: number;
            estado_geral: string;
        };
    }>;
    createProduto(tenantSlug: string, user: any, dto: any): Promise<{
        produto: any;
    }>;
    createMovimentacao(tenantSlug: string, user: any, dto: any): Promise<{
        movimentacao: any;
        nova_quantidade: any;
    }>;
    transferProduto(tenantSlug: string, user: any, dto: any): Promise<{
        message: string;
        nova_quantidade: number;
    }>;
    findMovimentacoes(tenantSlug: string, user: any, query: any): Promise<{
        movimentacoes: any;
    }>;
    findAlerts(tenantSlug: string, user?: any): Promise<{
        alertas: any;
        total_alertas: any;
        urgencia: string;
    }>;
    deleteProduto(tenantSlug: string, user: any, id: number): Promise<{
        message: string;
    }>;
}
